<?php
function XSLTransform($xmlString)
{
    $xslDoc = new DOMDocument();
    $xslDoc->load(sfConfig::get('sf_xsl_doc'));

    $xmlDoc = new DOMDocument();
    $xmlDoc->loadXML($xmlString);

    $proc = new XSLTProcessor();
    $proc->importStylesheet($xslDoc);

    return $proc->transformToXML($xmlDoc);
}
?>
